#pragma once
enum Side { NORTH, SOUTH };

const int NSIDES = 2;
const int POT = 0;
struct Hole {
	int beans = 0;
	Hole* next = nullptr;
};
class Board;
class Player;
class AlarmClock;

inline
Side opponent(Side s)
{
	return Side(NSIDES - 1 - s);
}

bool move(const AlarmClock& ac, Board& b, Side s, int hole, int depth);
void findMove(const AlarmClock& ac, const Board& b, Side s, int recursionDepth, int& bestHole, int& value, int numHoles);
//void display(const Board& b);